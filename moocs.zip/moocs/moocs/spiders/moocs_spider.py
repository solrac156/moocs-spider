# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import Request
import urlparse
from functools import partial

class MoocsSpiderSpider(scrapy.Spider):
	name = "moocs_spider"
	#allowed_domains = ["https://www.coursetalk.com/subjects/data-science/courses"]
	start_urls = ['https://www.coursetalk.com/subjects/data-science/courses']
	def parse(self, response):

		xpath_courses_links = '//*[@class="link-unstyled js-course-search-result"]//a/@href'
		courses_relative_links =  response.xpath(xpath_courses_links).re('.+/courses/.+')      
		courses_links = [urlparse.urljoin(response.url,courses_relative_url) for courses_relative_url in courses_relative_links ]     

		for course_link in courses_links:
			yield Request(course_link, callback=partial(self.extract_course_data))
		result_pages = [page for page in response.xpath('//*[@class="pagination"]//@href').extract() if '/courses' in page] 
		
		for page in result_pages:
			yield Request(page, callback=partial(self.parse))

  
		


	def extract_course_data(self,response):
		pass
		
